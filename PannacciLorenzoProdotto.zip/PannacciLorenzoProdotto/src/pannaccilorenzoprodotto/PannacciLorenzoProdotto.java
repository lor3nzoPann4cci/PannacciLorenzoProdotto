/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pannaccilorenzoprodotto;

/**
 *
 * @author pannacci.lorenzo
 */
public class PannacciLorenzoProdotto
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   

        Prodotto p1 = new Prodotto("Mouse", 0.2, 4.50, 0);
        Prodotto p2 = new Prodotto("Tastiera", 0.8, 25.00, 5);

        System.out.println("Primo prdotto");
        p1.stampaDati();

        System.out.println("\nSecondo prodotto");
        p2.stampaDati();

        System.out.println("\nVendita ");
        p1.vendi(3);
        p1.stampaDati();

        System.out.println("\nRifornimento");
        p1.rifornisci(5);
       

        System.out.println("\nConfronto");

        if (p1.confronta(p2)) {
            System.out.println("I prodotti sono uguali");
        } else {
            System.out.println("I prodotti sono diversi");
        }
    }   

       
}

        // TODO code application logic here
    
    

