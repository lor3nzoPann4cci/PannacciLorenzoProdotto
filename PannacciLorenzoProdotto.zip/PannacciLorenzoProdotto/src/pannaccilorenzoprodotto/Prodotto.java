/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pannaccilorenzoprodotto;

/**
 *
 * @author pannacci.lorenzo
 */
public class Prodotto {
   

    private String nome;
    private double peso;
    private double prezzo;
    private int numeroPezzi;

   
    public Prodotto(String nome, double peso, double prezzo, int numeroPezzi) {
        this.nome = nome;
        this.peso = peso;
        this.prezzo = prezzo;
        this.numeroPezzi = numeroPezzi;
    }

   
    public void vendi(int quantita) {
        if (quantita > 0 && quantita <= numeroPezzi) {
            numeroPezzi = numeroPezzi - quantita;
            System.out.println("Vendita effettuata");
        } else {
            System.out.println("Quantita non disponibile");
        }
    }

   
    public void rifornisci(int quantita) {
        if (quantita <= 0) {
            quantita = 5;
            numeroPezzi = numeroPezzi + quantita;
            System.out.println("Rifornimento effettuato");
        }
    }

   
    public boolean confronta(Prodotto p)
    {
        if (nome.equals(p.nome)
                          
               && peso == p.peso && prezzo == p.prezzo && numeroPezzi == p.numeroPezzi) 
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    
    public void stampaDati()
    {
        System.out.println("Nome: " + nome);
        System.out.println("Peso: " + peso + " kg");
        System.out.println("Prezzo: " + prezzo + " euro");
        System.out.println("Pezzi disponibili: " + numeroPezzi);
    }
}
   

    

